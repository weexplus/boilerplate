#!/usr/bin/env bash
./gradlew clean  assemble publish